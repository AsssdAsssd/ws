#include <iostream>
#include "hik_camera_pub.h"


int main(int argc, char **argv){
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CameraNode>("hik_camera_node1"));
    rclcpp::shutdown();
}