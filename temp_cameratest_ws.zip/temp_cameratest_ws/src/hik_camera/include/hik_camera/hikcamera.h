#ifndef ALAL_HIK_CAMERA_H
#define ALAL_HIK_CAMERA_H


#include <atomic> 
#include <MvCameraControl.h>
#include <opencv2/opencv.hpp>

#include <thread>
#include <unordered_map>
#include <functional>
#include <condition_variable> 

#define CAMERA_INFO(...) printf("[CCCcamera INFO] "); printf(__VA_ARGS__); printf("\n");
#define CAMERA_WARN(...) printf("\033[33m[CCCcamera WARN] "); printf(__VA_ARGS__); printf("\033[0m\n"); 
#define CAMERA_ERROR(...) printf("\033[31m[CCCcamera ERROR] "); printf(__VA_ARGS__); printf("\033[0m\n"); 

#if __has_include(<rclcpp/rclcpp.hpp>)
    #include <rclcpp/rclcpp.hpp>
    #define CAMERA_INFO(...) RCLCPP_INFO(rclcpp::get_logger("CCCcamera"), __VA_ARGS__)
    #define CAMERA_WARN(...) RCLCPP_WARN(rclcpp::get_logger("CCCcamera"), __VA_ARGS__)
    #define CAMERA_ERROR(...) RCLCPP_ERROR(rclcpp::get_logger("CCCcamera"), __VA_ARGS__)
#endif

// exec with warn
#define HIKEWW(func) \
    do { \
        nRet = (func); \
        if (nRet != MV_OK) { \
            CAMERA_WARN(#func " failed! Error code: 0x%x", (unsigned)nRet); \
        } \
    } while(0);

// exec with error
#define HIKEWE(func) \
    do { \
        nRet = (func); \
        if (nRet != MV_OK) { \
            CAMERA_ERROR(#func " failed! Error code: 0x%x", (unsigned)nRet); \
        } \
    } while(0);

// exec with recover
#define HIKEWR(func) \
    do { \
        nRet = (func); \
        if (nRet != MV_OK) { \
            CAMERA_ERROR(#func " failed! Error code: 0x%x, attempting recovery", (unsigned)nRet); \
            this->reopen(); \
        } \
    } while(0);


namespace camera_detail {

class CameraException : public std::exception {
   public:
    std::string info;
    CameraException(const std::string&& _info) : info{_info} {}
    const char* what() const noexcept { return info.c_str(); }
};


template<typename T>
concept image_type_t = requires(T img) {
    // 必须有uchar(ros2的uint8)
    requires std::same_as<decltype(img.data), unsigned char*> ||
            std::same_as<decltype(img.data), unsigned char[]> ||
            std::same_as<decltype(img.data), std::vector<unsigned char>>;
};

enum class CameraStatus{
    CLOSE = 0, // 相机关闭
    OPEN,  // 相机开启但未开始采集
    GRABING, // 相机正在采集
};

struct AlImageInfo{
    unsigned int height;
    unsigned int width;
    unsigned int channels;
    unsigned int step;
    unsigned int size;
};

enum class CameraUsageMode {
    SC=0,           // 单个相机
    MCSU,  // MultipleCamerasSingleUse 多个相机，一次只用一个
    MCCC  // MultipleCamerasConcurrent 多个相机，一次用多个（并发使用）
};

namespace hikcamera_detail {

class HikCameraManager;
class HikCamera{
public:
    struct Params{
        float frame_rate;
        int offset_x;
        int offset_y; 
        int grab_heigh;
        int grab_width;
        double exposure_time; 
        double gain; 
        double digital_shift;
        Params() = default;
        Params(
            float _frame_rate, 
            int _offset_x, int _offset_y,
            int _grab_heigh, int _grab_width,
            double _exposure_time, double _gain, double _digital_shift
        ):
            frame_rate(_frame_rate), 
            offset_x(_offset_x), offset_y(_offset_y),
            grab_heigh(_grab_heigh), grab_width(_grab_width), 
            exposure_time(_exposure_time), gain(_gain), digital_shift(_digital_shift){}
    };

    HikCamera():status(CameraStatus::CLOSE){};
    HikCamera(std::string _camera_sn):status(CameraStatus::CLOSE){
        this->init(_camera_sn);    
    }

    ~HikCamera(){
        // 关闭相机
        close();
    }

    // 初始化但不打开
    void init(std::string _camera_sn){
        MV_CC_DEVICE_INFO_LIST device_list;
        bool device_found = false;
        while (!device_found) {
            // 枚举设备
            HIKEWW(MV_CC_EnumDevices(MV_USB_DEVICE, &device_list));
            if (device_list.nDeviceNum > 0) {
                if (_camera_sn == "") {
                    HIKEWR(MV_CC_CreateHandle(&camera_handle, device_list.pDeviceInfo[0]));
                    device_found = true;
                } else {
                    static char device_sn[INFO_MAX_BUFFER_SIZE];
                    for (size_t i = 0; i < device_list.nDeviceNum; ++i) {
                        memcpy(device_sn,
                            device_list.pDeviceInfo[i]
                                ->SpecialInfo.stUsb3VInfo.chSerialNumber,
                            INFO_MAX_BUFFER_SIZE);
                        device_sn[63] = '\0'; // 以防万一
                        // CAMERA_INFO("Camera SN list: %s", device_sn);
                        if (std::strncmp(device_sn, _camera_sn.c_str(), 64U) == 0) {
                            HIKEWR(MV_CC_CreateHandle(&camera_handle, device_list.pDeviceInfo[i]));
                            device_found = true;
                            CAMERA_INFO("init camera %s successfully", device_sn);
                            break;
                        }
                    }
                }
            }
            if (!device_found){
                std::this_thread::sleep_for(std::chrono::seconds(1));
                CAMERA_INFO("Camera %s not found", _camera_sn.c_str());
            }
        }
    }

    // set params变量
    void set_params(const Params& _p){
        params = _p;
    }

    // 应用params
    void apply_params(){
        // 应用参数前关闭采集
        if(status != CameraStatus::OPEN){
            CAMERA_ERROR("open camera and stop grab before apply params");
            return;
        }

        HIKEWW(MV_CC_SetBoolValue(camera_handle, "DigitalShiftEnable", true))
        HIKEWW(MV_CC_SetEnumValue(camera_handle, "GainAuto", MV_GAIN_MODE_OFF))
        HIKEWW(MV_CC_SetEnumValue(camera_handle, "ExposureMode", MV_EXPOSURE_AUTO_MODE_OFF))
        HIKEWW(MV_CC_SetEnumValue(camera_handle, "TriggerMode", MV_TRIGGER_MODE_OFF))
        HIKEWW(MV_CC_SetBoolValue(camera_handle, "BlackLevelEnable", true))
        HIKEWW(MV_CC_SetEnumValue(camera_handle, "BalanceWhiteAuto", MV_BALANCEWHITE_AUTO_ONCE))
        HIKEWW(MV_CC_SetEnumValue(camera_handle, "AcquisitionMode", MV_ACQ_MODE_CONTINUOUS))
        HIKEWW(MV_CC_SetFloatValue(camera_handle, "AcquisitionFrameRate", params.frame_rate))
        HIKEWW(MV_CC_SetBoolValue(camera_handle, "AcquisitionFrameRateEnable", true))

        // 获取max height/width
        MVCC_INTVALUE mvcc_height_max, mvcc_width_max;
        HIKEWW(MV_CC_GetIntValue(camera_handle, "HeightMax", &mvcc_height_max));
        HIKEWW(MV_CC_GetIntValue(camera_handle, "WidthMax", &mvcc_width_max));

        auto max_height = static_cast<int>(mvcc_height_max.nCurValue), 
            max_width = static_cast<int>(mvcc_width_max.nCurValue);
        // 自动调整offset
        if (params.offset_y == -1) params.offset_y = (max_height - params.grab_heigh) / 2;
        if (params.offset_x == -1) params.offset_x = (max_width - params.grab_width) / 2;

        // 先将offset置零的原因是, 这些SetValue会保持到下一次运行,
        // 如果原先存在的offset较大且与下一次设置的Width/Height加起来大于可用像素(如1080), SDK会拒绝设置
        // 先设置offset成正确值则存在如果事先设置的Width较大且本次设置的Offset也较大, 同样也会拒绝
        // 先置offset零然后设置就不会产生冲突
        HIKEWW(MV_CC_SetIntValue(camera_handle, "OffsetX", 0))
        HIKEWW(MV_CC_SetIntValue(camera_handle, "OffsetY", 0))
        HIKEWW(MV_CC_SetIntValue(camera_handle, "Height", params.grab_heigh))
        HIKEWW(MV_CC_SetIntValue(camera_handle, "Width", params.grab_width))

        align_to_step("OffsetX", params.offset_x);
        align_to_step("OffsetY", params.offset_y);

        HIKEWW(MV_CC_SetIntValue(camera_handle, "OffsetX", params.offset_x))
        HIKEWW(MV_CC_SetIntValue(camera_handle, "OffsetY", params.offset_y))

        HIKEWW(MV_CC_SetFloatValue(camera_handle, "ExposureTime", params.exposure_time))

        HIKEWW(MV_CC_SetFloatValue(camera_handle, "Gain", params.gain)) 
        HIKEWW(MV_CC_SetFloatValue(camera_handle, "DigitalShift", params.digital_shift))
        // 获取有关Image的数据
        MV_CC_GetImageInfo(camera_handle, &mv_img_info);
        
        // 不放在fill_image_data里，避免频繁赋值
        convert_param.nWidth = mv_img_info.nWidthValue;
        convert_param.nHeight = mv_img_info.nHeightValue;
        convert_param.enDstPixelType = PixelType_Gvsp_BGR8_Packed;

        // set image info
        al_img_info.height = mv_img_info.nHeightValue;
        al_img_info.width = mv_img_info.nWidthValue;
        al_img_info.channels = 3;
        al_img_info.step = mv_img_info.nWidthValue * 3;
        al_img_info.size = static_cast<unsigned int>(mv_img_info.nWidthValue * mv_img_info.nHeightValue * 3);
    }

    const AlImageInfo& get_img_info() const{
        return al_img_info;
    }

    /**
     * @brief 打开相机,设置相机参数,但不开始采集
    */
    void open(){
        HIKEWR(MV_CC_OpenDevice(camera_handle));
        HIKEWR(MV_CC_CloseDevice(camera_handle));
        // 来回开关, 确保相机状态正常(增强鲁棒性措施)
        HIKEWR(MV_CC_OpenDevice(camera_handle));
        // apply_params前更新状态
        status = CameraStatus::OPEN;
        
        apply_params();
    };
    
    /**
     * @brief 打开相机,同时应用传入的参数配置名,存到类中,但不开始采集
    */
    void open(Params _p){
        set_params(_p);
        open();
    }

    /**
     * @brief 进入采集模式
    */
    void start_grab(){
        MV_CC_StartGrabbing(camera_handle);
        status = CameraStatus::GRABING;
    }

    /**
     * @brief 退出采集模式但不关闭相机
    */

    void stop_grab(){
        if (camera_handle) {
            MV_CC_StopGrabbing(camera_handle);
        }
        status = CameraStatus::OPEN;
    }

    /**
     * @brief 停止采集并且关闭相机
    */
    void close(){
        stop_grab();
        if (camera_handle) {
            MV_CC_CloseDevice(camera_handle);
            MV_CC_DestroyHandle(camera_handle);
        }
        status = CameraStatus::CLOSE;
    }

    void reopen(){
        close();
        std::this_thread::sleep_for(std::chrono::seconds(1));
        open();
        // start_grab();
    }

    // 相机是否异常
    [[nodiscard("returned value must be used")]] bool is_camera_faulty(){
        return camera_failed.load();
    }

    template<image_type_t T>
    [[nodiscard]] bool fill_image_data(T& image){
        nRet = MV_CC_GetImageBuffer(camera_handle, &pst_frame, 1000);
        
        if(nRet == MV_OK){
            if constexpr (std::is_same_v<decltype(image.data), unsigned char*>) {
                convert_param.pDstBuffer = image.data;
            } else if constexpr (std::is_same_v<decltype(image.data), unsigned char[]>) {
                convert_param.pDstBuffer = static_cast<unsigned char*>(image.data);
            } else if constexpr (std::is_same_v<decltype(image.data), std::vector<unsigned char>>) {
                convert_param.pDstBuffer = image.data.data();
            }
            convert_param.nDstBufferSize = al_img_info.size;
            convert_param.pSrcData = pst_frame.pBufAddr;
            convert_param.nSrcDataLen = pst_frame.stFrameInfo.nFrameLen;
            convert_param.enSrcPixelType = pst_frame.stFrameInfo.enPixelType;

            MV_CC_ConvertPixelType(camera_handle, &convert_param);
            MV_CC_FreeImageBuffer(camera_handle, &pst_frame);
            fail_cnt=0;
        }else{
            ++fail_cnt;
        }
        if(fail_cnt > 5){
            fail_cnt=0;
            camera_failed.store(false);
        }

        return nRet == MV_OK;
    }

    // void free_image_buffer(MV_FRAME_OUT * _pst_frame){
    //     MV_CC_FreeImageBuffer(camera_handle, _pst_frame);
    // }

private:

    void align_to_step(std::string property, int& value) {
        if (value < 0) {
            throw std::invalid_argument("fit_in_step: value is negative, value: " +
                                        std::to_string(value));
        }
        MVCC_INTVALUE m;
        HIKEWW(MV_CC_GetIntValue(camera_handle, property.c_str(), &m))
        int step = m.nInc;
        if (value % step) {
            value -= value % step;
        }
        if (value < (int)m.nMin || value > (int)m.nMax) {
            throw CameraException(
                "Property: '" + property + "'set value out of range, min: " + std::to_string(m.nMin) +
                ", max: " + std::to_string(m.nMax) + ", current: " + std::to_string(value));
        }
    }

    Params params;
    int nRet = MV_OK;
    void* camera_handle;
    CameraStatus status;

    MV_IMAGE_BASIC_INFO mv_img_info;
    MV_CC_PIXEL_CONVERT_PARAM convert_param;
    MV_FRAME_OUT pst_frame; // image data的缓存
    AlImageInfo al_img_info;

    int fail_cnt = 0;
    std::atomic<bool> camera_failed{false};

    friend class HikCameraManager;
};

class HikCameraManager{
public:
    HikCameraManager() = default;
    HikCameraManager(CameraUsageMode _camera_usage_mode):camera_usage_mode(_camera_usage_mode){};
    ~HikCameraManager(){
        close_all_camera();
    }

    void register_grab_task(std::string _grab_task_name, std::function<void()> _grab_task_func){
        auto task_iter = task_infos.find(_grab_task_name);
        if (task_iter == task_infos.end()){
            task_infos.emplace(_grab_task_name, std::move(_grab_task_func));
        }else{
            if(task_iter->second.task_func.target<void(*)()>() != _grab_task_func.target<void(*)()>()){
                // CAMERA_WARN("")
            }
        }
    }

    void register_camera(std::string _camera_sn, std::string _grab_task_name, const HikCamera::Params& _p){
        // 确保相机对应的都是已注册任务
        if(!task_infos.contains(_grab_task_name)){
            CAMERA_ERROR("unregister task");
            return;
        }

        if(camera_usage_mode == CameraUsageMode::SC && camera_infos.size() == 1){
            CAMERA_WARN("Current Mode is Single Camera and already have one");
            return;
        }

        camera_infos.try_emplace(_camera_sn, _camera_sn, _grab_task_name);
        auto& cur_caminfo = camera_infos.at(_camera_sn);
        cur_caminfo.camera.init(_camera_sn);
        cur_caminfo.camera.open(_p);
    }


    /** 
     * @brief 启动指定相机使其开始执行采集任务, 多个相机可以做同一个采集任务（同一个task_func）但是一个采集任务一次只能有一个相机在执行
    */
    void start_appointed_camera(const std::string& _camera_sn){
        auto caminfo_iter = camera_infos.find(_camera_sn);
        if(caminfo_iter != camera_infos.end()){
            if(caminfo_iter->second.camera.status == CameraStatus::GRABING){
                CAMERA_WARN("The Camera in Grabbing Mode");
                return;
            }
            start_valid_camera(caminfo_iter);
        }
    }

    // 停止指定相机及对应采集任务
    void stop_appointed_camera(const std::string& _camera_sn){
        auto caminfo_iter = camera_infos.find(_camera_sn);
        if(caminfo_iter != camera_infos.end()){
            if(caminfo_iter->second.camera.status != CameraStatus::GRABING) return;

            stop_valid_camera(caminfo_iter);
        }
    }
    
    void close_all_camera(){
        for(auto& c_pair : camera_infos){
            stop_appointed_camera(c_pair.first);
            c_pair.second.camera.close();
        }
    } 

    template<image_type_t T>
    [[nodiscard]] bool fill_image(T& image){
        // 获取当前执行采集任务的线程对应的相机sn
        auto tid = std::this_thread::get_id();
        const auto& sn = tid_to_sn.at(tid);
        
        auto caminfo_iter = camera_infos.find(
            sn
        );
        
        if(caminfo_iter != camera_infos.end()){
            return caminfo_iter->second.camera.fill_image_data(image);
        }else {
            CAMERA_ERROR("can't get image from invalid camera");
            return false;
        }
    }

    // void free_buffer(MV_FRAME_OUT *_pst_frame){
    //     auto caminfo_iter = camera_infos.find(in_grab_camera_sn);
    //     if(caminfo_iter != camera_infos.end()){
    //         caminfo_iter->second.camera.free_image_buffer(_pst_frame);
    //     }
    // }

    // 设置并应用传入相机参数
    void set_and_apply_camera_params(std::string _camera_sn, HikCamera::Params _p){
        auto caminfo_iter = camera_infos.find(_camera_sn);
        if(caminfo_iter != camera_infos.end()){
            auto& cam = caminfo_iter->second.camera;

            if(cam.status != CameraStatus::GRABING){
                // 非grab模式直接设置
                cam.set_params(_p);
                cam.apply_params();
            }else{
                // 先停止grab
                stop_valid_camera(caminfo_iter);

                cam.set_params(_p);
                cam.apply_params();
                // 重新启动
                start_valid_camera(caminfo_iter);
            }
        }
    }


    // 当return 为 true 时才可以获取到图像, 同时必须将其作为线程内获取图像的while循环（若有）内的必要条件 
    [[nodiscard]] bool allow_grab_task() const {
        auto tid = std::this_thread::get_id();
        return (tid_to_sn.contains(tid) // 确保当前线程对应一个已启动相机
                && 
                // 执行标识符
                task_infos.at(camera_infos.at(tid_to_sn.at(tid)).task_name).is_executing.load()
            );
    }

    const std::string& get_current_thread_camera_sn(){
        static std::string default_res = "none";
        auto tid = std::this_thread::get_id();
        if(tid_to_sn.contains(tid)){
            return tid_to_sn.at(tid);
        }else {
            return default_res;
        }
    }

    AlImageInfo get_current_thread_camera_img_info(){
        static std::string default_res = "none";
        auto tid = std::this_thread::get_id();
        if(tid_to_sn.contains(tid)){
            return camera_infos.at(tid_to_sn.at(tid)).camera.get_img_info();
        }else {
            return AlImageInfo{};
        }
    }
    
private:
    struct CameraInfo{
        HikCamera camera;
        std::string task_name;
        // 放这里还是放外面？
        std::thread task_thread;
        CameraInfo(std::string _sn, std::string _tn):camera(_sn),task_name(_tn){}
        ~CameraInfo(){
            if(task_thread.joinable()) task_thread.join();
        }
    };
    
    struct TaskInfo{
        // 采集任务info
        std::function<void()> task_func;
        std::string executing_sn;
        std::atomic<bool> is_executing;
        TaskInfo(std::function<void()> _tfunc):
                task_func(_tfunc), 
                executing_sn(""), is_executing(false){}
    };

    // 启动 可启动(未在grabbing模式，未开始工作线程) 的相机
    void start_valid_camera(std::unordered_map<std::string, CameraInfo>::iterator _caminfo_iter){
        
        _caminfo_iter->second.camera.start_grab();

        auto& taskinfo = task_infos.at(_caminfo_iter->second.task_name);
        // 更新让task_func能执行的参数;
        auto& camera_sn = _caminfo_iter->first;
        _caminfo_iter->second.task_thread = std::thread([&taskinfo, &camera_sn](){
                taskinfo.is_executing.store(true);
                taskinfo.executing_sn = camera_sn;
                taskinfo.task_func();
            }
        );
        {
            std::lock_guard<std::mutex> lock(tid_to_sn_mtx);
            tid_to_sn.emplace(_caminfo_iter->second.task_thread.get_id(), _caminfo_iter->first);
        }
    }

    void stop_valid_camera(std::unordered_map<std::string, CameraInfo>::iterator _caminfo_iter){
        auto& taskinfo = task_infos.at(_caminfo_iter->second.task_name);
        // 缓存线程id
        auto temp_id = _caminfo_iter->second.task_thread.get_id();

        // 更新参数使task_func不再执行
        taskinfo.is_executing.store(false);
        taskinfo.executing_sn = "";
        
        if(_caminfo_iter->second.task_thread.joinable()) _caminfo_iter->second.task_thread.join();
        _caminfo_iter->second.camera.stop_grab();
        // 先关闭线程再擦除，避免线程中访问已擦除pair
        tid_to_sn.erase(temp_id);
    }


    // sn -> camera_info
    std::unordered_map<std::string, CameraInfo> camera_infos;
    // task_name -> task_info
    std::unordered_map<std::string, TaskInfo> task_infos;
    // thread_id -> 绑定该线程的执行采集任务的相机sn
    std::unordered_map<std::thread::id, std::string> tid_to_sn;
    std::mutex tid_to_sn_mtx;
    CameraUsageMode camera_usage_mode;
    // std::thread task_thread;
    // TODO
    // monitor_thread; // 监视线程，定时检查相机状态，重启失效的相机
};

} // namespace hikcamera_detail

}; // namespace camera

using HikCameraManager = camera_detail::hikcamera_detail::HikCameraManager;
using HikCameraParam = camera_detail::hikcamera_detail::HikCamera::Params;
const camera_detail::CameraUsageMode SinglelMode = camera_detail::CameraUsageMode::SC;
const camera_detail::CameraUsageMode DoubleMode = camera_detail::CameraUsageMode::MCCC;
#endif // ALAL_HIK_CAMERA_H

