#include <iostream>
#include "hikcamera.h"
#include "common.h"
#include <sensor_msgs/msg/image.hpp>
#include <opencv2/opencv.hpp>
#include "cv_bridge/cv_bridge.h"
#include "std_msgs/msg/header.hpp"

#include <stdio.h>
#include <time.h>

namespace hikd = camera_detail::hikcamera_detail;

class TestClass
{

private:
    rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr publisher_;

public:
    TestClass() : manager(camera_detail::CameraUsageMode::SC) {};

    TestClass(std::string _camera_sn) : manager(camera_detail::CameraUsageMode::SC)
    {

        // publisher_ = this->create_publisher<sensor_msgs::msg::Image>("image", 10);
        manager.register_grab_task("task1", std::bind(&TestClass::grab, this));

        manager.register_camera(_camera_sn, "task1",
                                hikd::HikCamera::Params(150, -1, -1,
                                                        640, 640, 6000,
                                                        15, 5));
        // float frame_rate; offset_x; offset_y;
        // int grab_heigh; int grab_width; double exposure_time;
        // double gain;  double digital_shift;
        manager.start_appointed_camera(_camera_sn);
        int c;
        std::cin >> c;
        if (c == 11)
        {
            manager.stop_appointed_camera(_camera_sn);
        }
    }

    TestClass(std::string _camera_sn, rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr image_publisher)
        : manager(camera_detail::CameraUsageMode::SC), publisher_(image_publisher)
    {
        manager.register_grab_task("task1", std::bind(&TestClass::grabandpublish, this));
        manager.register_camera(_camera_sn, "task1",
                                hikd::HikCamera::Params(150, -1, -1,
                                                        640, 640, 6000,
                                                        15, 5));
        // float frame_rate; offset_x; offset_y;
        // int grab_heigh; int grab_width; double exposure_time;
        // double gain;  double digital_shift;
        manager.start_appointed_camera(_camera_sn);
        info_log("start to publish image");
        int c;
        std::cin >> c;
        if (c == 11)
        {
            manager.stop_appointed_camera(_camera_sn);
        }
    }

    TestClass(std::string _camera_sn, std::string _camera_sn1) : manager(camera_detail::CameraUsageMode::MCCC)
    {
        manager.register_grab_task("task1", std::bind(&TestClass::grab, this));
        manager.register_camera(_camera_sn, "task1",
                                hikd::HikCamera::Params(150, -1, -1,
                                                        640, 640, 6000,
                                                        15, 5));
        manager.register_camera(_camera_sn1, "task1",
                                hikd::HikCamera::Params(150, -1, -1,
                                                        640, 640, 6000,
                                                        15, 5));

        manager.start_appointed_camera(_camera_sn);
        manager.start_appointed_camera(_camera_sn1);
        int c;
        std::cin >> c;
        if (c == 11)
        {
            manager.stop_appointed_camera(_camera_sn);
            manager.stop_appointed_camera(_camera_sn1);
        }
    }

    TestClass(std::string _camera_sn, std::string _camera_sn1, int a) : manager(camera_detail::CameraUsageMode::MCSU)
    {
        manager.register_grab_task("task1", std::bind(&TestClass::grab, this));
        manager.register_camera(_camera_sn, "task1",
                                hikd::HikCamera::Params(150, -1, -1,
                                                        640, 640, 6000,
                                                        15, 5));
        manager.register_camera(_camera_sn1, "task1",
                                hikd::HikCamera::Params(150, -1, -1,
                                                        640, 640, 6000,
                                                        15, 5));

        int c;
        while (std::cin >> c)
        {
            if (c == 11)
                break;
            if (c == 1)
            {
                manager.stop_appointed_camera(_camera_sn1);
                manager.start_appointed_camera(_camera_sn);
            }
            if (c == 2)
            {
                manager.stop_appointed_camera(_camera_sn);
                manager.start_appointed_camera(_camera_sn1);
            }
        }
    }

    void grab()
    {
        auto info = manager.get_current_thread_camera_img_info();
        cv::Mat img(info.height, info.width, CV_8UC3, cv::Scalar(255, 0, 0));
        while (manager.allow_grab_task())
        {
            bool fill_flag = manager.fill_image<cv::Mat>(img);
            if (fill_flag)
            {
                cv::imshow(manager.get_current_thread_camera_sn(), img);
                std::cout << "fuclk5\n";
                cv::waitKey(1);

                // auto header = std_msgs::msg::Header();
                // header.frame_id = "camera_frame";

                // // 转换OpenCV帧为ROS2 Image消息
                // auto ros_image = cv_mat_to_ros_image(img, header);

                // if (ros_image)
                // {
                //     // 关键修正1：直接发布转换后的ros_image（不是新建空的message）
                //     publisher_->publish(*ros_image);
                //     // 打印日志，显示发布的帧尺寸（方便调试
                //       std::cout << "ok";
                // }
                // else
                // {
                //             std::cout << "sorry";
                // }
            }
        }
        cv::destroyAllWindows();
        std::cout << "over\n";
    }

    sensor_msgs::msg::Image::SharedPtr cv_mat_to_ros_image(const cv::Mat &cv_image, const std_msgs::msg::Header &header)
    {
        try
        {
            cv_bridge::CvImage cv_bridge_image(header, sensor_msgs::image_encodings::BGR8, cv_image);
            return cv_bridge_image.toImageMsg();
        }
        catch (const cv_bridge::Exception &e)
        {
            std::cout << "cv_bridge异常: %s";
            return nullptr;
        }
    }

    void grabandpublish()
    {
        auto info = manager.get_current_thread_camera_img_info();

        std::cout << "相机图像尺寸：height=" << info.height << ", width=" << info.width << std::endl;

        // sensor_msgs::msg::Image image;
        while (manager.allow_grab_task())
        {
            cv::Mat img(info.height, info.width, CV_8UC3, cv::Scalar(255, 0, 0));
            bool fill_flag = manager.fill_image<cv::Mat>(img);
            if (fill_flag)
            {
                float scale = 0.6;
                cv::resize(img, img, cv::Size(img.cols * scale, img.rows * scale));
                // 应该是filimage生成的mat内存保存方式和cv库的有差异,会导致cv_brigde转换乱码，resize一下才行
                cv::imshow(manager.get_current_thread_camera_sn(), img);
                // std::cout << "fuclk5\n";
                if (cv::waitKey(1) == 'q')
                {
                    rclcpp::shutdown();
                    return;
                }

                auto header = std_msgs::msg::Header();
                header.frame_id = "camera_frame";

                auto image = cv_mat_to_ros_image(img, header);

                if (image)
                {
                    publisher_->publish(*image);

                    // clock_gettime(CLOCK_REALTIME, &ts);

                    // time_t t = ts.tv_sec;
                    // struct tm *tm = localtime(&t);

                    // printf("当前时间： %04d-%02d-%02d %02d:%02d:%02d.%03ld\n", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec, ts.tv_nsec / 1000000);

                    // std::cout << "ok";
                }
                else
                {
                    std::cout << "sorry";
                }
            }
        }
        cv::destroyAllWindows();
        std::cout << "over\n";
    }
    struct timespec ts;
    hikd::HikCameraManager manager;
};

//     void grabandpublish()
//     {
//         auto info = manager.get_current_thread_camera_img_info();
//         // cv::Mat img(info.height, info.width, CV_8UC3, cv::Scalar(255, 0, 0));
//         sensor_msgs::msg::Image image;
//         while (manager.allow_grab_task())
//         {
//             bool fill_flag = manager.fill_image<sensor_msgs::msg::Image>(image);
//             if (fill_flag)
//             {
//                 publisher_->publish(image);
//                 std::cout << "fuclk5\n";
//             }

//         }
//         cv::destroyAllWindows();
//         std::cout << "over\n";
//     }

//     hikd::HikCameraManager manager;
// };

class CameraNode : public rclcpp::Node
{
private:
    rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr image_publisher;

public:
    CameraNode(std::string name) : Node(name)
    {
        image_publisher = this->create_publisher<sensor_msgs::msg::Image>("image", 10);
        info_log(name, "has been built!");
        TestClass t1("J67763857", image_publisher);
    }
};