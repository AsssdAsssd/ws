#pragma once
#include <rclcpp/rclcpp.hpp>
#include <iostream>
using namespace std;


// #include <rm_msgs/msg/target.hpp>
// using target_msg = rm_msgs::msg::Target;


inline void info_log() {std::cout << "\33[0m" << std::endl;}
// 发布绿色信息
template<typename T, typename... Args>
void info_log(T element, Args... args) {
    std::cout << "\33[32m" << element << " "; 
    info_log(args...);         
}

inline void error_log() {std::cout << "\33[0m" << std::endl;}
// 发布红色信息
template<typename T, typename... Args>
void error_log(T element, Args... args) {
    std::cout << "\33[31m" << element << " "; 
    error_log(args...);         
}
