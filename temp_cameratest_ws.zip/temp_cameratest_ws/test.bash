rm -rf build install log
colcon build
source install/setup.bash
ros2 run hik_camera hik_camera_node
